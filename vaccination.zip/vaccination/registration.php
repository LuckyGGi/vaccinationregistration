<?php   
require_once('config.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Vaccination Registration</title>
</head>
<body>



<div> 
        <?php 
        if(isset($_POST['create'])){

            $name           = $_POST['name'];
            $email          = $_POST['email'];
            $phonenumber    = $_POST['phonenumber'];
            $nationalid     = $_POST['nationalid'];
            $date           = $_POST['date'];
            $time           = $_POST['time'];

            $sql = "INSERT INTO users (name, email, phonenumber, nationalid, date, time) VALUES(?,?,?,?,?,?)";
            $stmtinsert = $db->prepare($sql);
            $result = $stmtinsert->execute([$name, $email, $phonenumber, $nationalid, $date, $time]);
            if($result){
                echo 'Succesfully saved.';
            }else{
                echo 'There were errors while saving the date';
            }
            }
        ?>
        </div>

    <div>
        <form action="registration.php" method="post">
            <div class="container">

            <div class="row">
                <div class="col-sm-3">

            </div>
                <h1>Registration</h1>
                <p>Fill up  the form with personal information.</p>
                <hr class="mb-3">
                <label for="name"><b>name</b></label>
                <input type="text" name="name" required>

                <label for="email"><b>Email</b></label>
                <input type="text" name="email" required>

                <label for="phonenumber"><b>Phone Number</b></label>
                <input type="text" name="phonenumber" required>

                <label for="Nationalid"><b>National identification number</b></label>
                <input type="text" name="nationalid" required>

                <label for="date"><b>Date</b></label>
                <input type="text" name="date" required>

                <label for="time"><b>time</b></label>
                <input type="text" name="time" required>

                <!-- <label for="password"><b>Password</b></label>
                <input type="password" name="password" required>
                <hr class="mb-3"> -->
                

                <input class="btn btn-primary" type="submit" name="create" value="submit">
            </div>
            </div>
        </form>
    </div>
    
</body>
</html>